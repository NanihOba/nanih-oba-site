
document.addEventListener("DOMContentLoaded", () => {
    console.log("Nanih Oba Portal Active");
});
